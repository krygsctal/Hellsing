<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    echo " Tipe Data 1 : ";
    var_dump("IWIMA");
    echo "<br>";

    echo " Tipe Data 2 : ";
    var_dump(100);
    echo "<br>";

    echo " Tipe Data 3 : ";
    var_dump(3.5);
    ?>
    
</body>
</html>