<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variable Array</title>
</head>
<body>
    <?php 
    $values = array(1,2,3,4);
    $rank = ["R1","R2","R3"];
    var_dump($values);
    echo "<br>";
    var_dump($rank);

    ?>
</body>
</html>