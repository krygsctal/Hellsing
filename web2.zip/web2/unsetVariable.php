<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UNSET VARIABLE</title>
</head>
<body>
    <?php 
    $nama = "ZENTOL";
    unset($nama);
    var_dump(isset($nama));
    
    echo "<br>";
    $nama = "ZENTOL";
    var_dump(isset($nama));
    ?>
</body>
</html>