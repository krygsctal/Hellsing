<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variabel</title>
</head>
<body>
    <?php 
    $nama = "ZENTOL";
    $korps = "Warrior Secret Force";
    echo "Nama : ";
    echo $nama;
    echo "<br>";

    echo "Korps : ";
    echo $korps;
    echo "<br>";

    ?>
</body>
</html>