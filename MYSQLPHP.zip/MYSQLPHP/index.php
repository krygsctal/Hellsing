<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>input pesan</title>
</head>
<body>
    <h2>buenos dias</h2>    
    <form action="proses.php" method="post">
        <label for="">nama</label> <br>
        <input type="text" nama ="nama"> <br>
        
        <label for="">Pesan</label> <br>
        <textarea name="pesan" id=""></textarea> <br>

        <button type="submit">save</button> 
        <button type="reset">reset</button>
        </form>
        <hr>
        <h2>daftar</h2>
        <table border="1">
        <tr>
            <th>no</th>
            <th>nama</th>
            <th>pesan</th>
            <th>tanggal</th>
        </tr>
        <?php 
        include "koneksi.php";
        $sql = "select * from tbphp";
        $data =mysqli_query($koneksi, $sql);
        while ($row = mysqli_fetch_array($data))
            {
                ?>
                <tr> 
                <td> <?php echo $nomor?></td>
                <td> <?php echo $row['nama']?></td>
                <td> <?php echo $row['pesan']?></td>
                <td> <?php echo $row['create_at']?></td>
                </tr>
           
        
              
             <?php 
                    $nomor++;
            }?>

        </table>
</body>
</html>