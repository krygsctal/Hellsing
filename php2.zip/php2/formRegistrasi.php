<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORM REGISTRASI</title>
</head>
<form action="registrasi.php2" method="post">
    <h2> Input Data Registrasi</h2>
    <label for="">Nama</label> <br>
    <input type="text" name="nama"> <br>
    
    <label for="">Email</label> <br>
    <input type="email" name="email"> <br>
    
    <label for="">Jenis Kelamin</label> <br>
    <select name="jenis_kelamin" id=""> <br>

    <option value="LAKI-LAKI">Laki-Laki</option>
    <option value="PEREMPUAN">Perempuan</option>

    </select> <br>

    <label for="">Alamat</label> <br>
    <textarea name="alamat" id=""></textarea> <br>
 
    <button type="submit">Save</button>
    <button type="reset">Cancel</button>
</form>

<body>
    
</body>
</html>